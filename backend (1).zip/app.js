const express = require("express");
const app = express();
const cors = require("cors");
const mongoose = require("mongoose");
require("dotenv").config();
const morgan = require("morgan");

//Db Connection
mongoose
	.connect(process.env.DB, {
		useNewUrlParser: true,
		useUnifiedTopology: true,
	})
	.then(() => console.log("Database Connected........."))
	.catch((err) => console.log("Database Not Connected !!!"));

//import Routes
const authrouter = require("./Routes/User/auth");
const authotprouter = require("./Routes/User/otp");
const adminauthrouter = require("./Routes/Admin/auth");
const adminsliderouter = require("./Routes/Admin/slider");
const adminphaserouter = require("./Routes/Admin/phase");
const adminstudentrouter = require("./Routes/Admin/student");
const adminprofessorouter = require("./Routes/Admin/professor");
const admincourseorouter = require("./Routes/Admin/course");
const usersubscribe = require("./Routes/User/subscribe");
const userpayment = require("./Routes/User/payment");

//middleware
app.use(morgan("dev"));
app.use(cors());
app.use(express.static("public"));
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

//creating Routes
app.use("/api/user", authrouter);
app.use("/api", authotprouter);
app.use("/api/admin", adminauthrouter);
app.use("/api", adminsliderouter);
app.use("/api", adminphaserouter);
app.use("/api", adminstudentrouter);
app.use("/api", adminprofessorouter);
app.use("/api", admincourseorouter);
app.use("/api", usersubscribe);
app.use("/api", userpayment);

app.get("/", (req, res) => {
	res.send("Hello, Jimmy!");
});

const PORT = process.env.PORT || 8000;

app.listen(PORT, () => {
	console.log(`Server running at http://localhost:${PORT}`);
});
