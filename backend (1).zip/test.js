//model

const mongoose=require("mongoose");

const transactionSchema= mongoose.Schema({
   
    amount:{
        type:String
    },
    customerId:{
        type:String
    },
    customername:{
        type:String
    },
     email:{
        type:String
    },
    type:{
        type:String
    },
    paymentdate:{
        type:String
    },
   
    phonenumber:{
        type:String
    },
    paymentId:{
        type:String
    }
   
   
}
    )
   
    const transactionModel = mongoose.model("transactiondetails", transactionSchema);
module.exports = transactionModel;



//controller


const transactinModel=require("../../models/admin/transaction")

class transaction{
   
    async posttransaction(req, res) {
let { amount, customerId,customername,email,phonenumber,paymentId,type,paymentdate } = req.body;

try {
if (!amount || !paymentId) {
return res.status(500).json({ error: "failed" });
} else {
let newcustomer = new transactinModel({
amount,
customerId,
customername,
type,
paymentdate,
email,
phonenumber,
paymentId
});
let save = newcustomer.save();
if (save) {
return res.json({ success: "Saved" });
}
}
} catch (error) {
console.log(error);
}
}

async gettransactiondetails(req,res){
let transaction = await transactinModel.find({});
    if (transaction) {
      return res.status(200).json({ transaction: transaction });
    } else {
      return res.status(500).json({ error: "something went wrong" });
    }
   
}


}


const transactionController = new transaction();
module.exports = transactionController;


//routers

const express = require("express");
const router = express.Router();
const transactionController = require("../../controller/admincontroller/transaction");

router.post("/transaction/posttransactionorderdetails", transactionController.posttransaction);
router.get("/gettransactionorderdetails", transactionController.gettransactiondetails);

module.exports = router;