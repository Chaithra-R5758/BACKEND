const mongoose  = require("mongoose");
const Schema  = mongoose.Schema;

const slider = new Schema(
    {
        slider:{
            type:String
        },
        content:{
            type:String
        },
    }
)
 
const sliderModel = mongoose.model("slider", slider);
module.exports = sliderModel;
