const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const phase = new Schema(
    {
        phasename:{
            type:String
        },
        phaseimage:{
            type:String
        },
        phasetitle:{
            type:String
        }
    }
)

const phaseModel = mongoose.model('phase', phase);
module.exports=phaseModel;