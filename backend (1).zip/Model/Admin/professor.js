const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const professor = new Schema(
    {
        professorname:{
            type:String
        },
        professorimage:{
            type:String
        },
        position:{
            type:String
        },
        instagram:{
            type:String
        },
        facebook:{
            type:String
        },
        whatsapp:{
            type:String
        }
    }
)

const professorModel = mongoose.model('professor', professor);
module.exports=professorModel;