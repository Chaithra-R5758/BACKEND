const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const student = new Schema(
    {
        studentname:{
            type:String
        },
        feedback:{
            type:String
        },
        studentimage:{
            type:String
        }
    }
)

const studentModel = mongoose.model('student', student);
module.exports=studentModel;