const mongoose = require("mongoose");
const Scheme = mongoose.Schema;
const { ObjectId } = mongoose.Schema.Types;

const course = new Scheme(    
    {
        coursename:{
            type:String
        },
        phaseid:{
            type: ObjectId,
            ref:"phases"
        },
        courseimage:{
            type:String
        },
        coursefor:{
            type:String
        },
        fees:{
            type:String
        },
        courseperiod:{
            type:String
        }
    }
    )
const  courseModel = mongoose.model("course", course);
module.exports = courseModel;