const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const user = new Schema(
	{
		name: {
			type: String,
		},
		email: {
			type: String,
		},
		mobile: {
			type: String,
		},
		password: {
			type: String,
		},

		profile: {
			type: String,
		},
		status: {
			type: String,
			default: "Offline",
			enum: ["Online", "Offline"],
		},
	},
	{ timestamps: true }
);

const userModel = mongoose.model("user", user);
module.exports = userModel;
