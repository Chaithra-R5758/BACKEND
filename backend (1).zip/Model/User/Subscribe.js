const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const { ObjectId } = mongoose.Schema.Types;

const subscribeUser = new Schema({
    studentid:{
        type: ObjectId,
        ref:"users"
    },
    
    name: {
       type: String
    },
    email: {
        type: String
    },
    mobile: {
        type:  String
    },
    address:{
        type: String
    },
    institute:{
        type: String
    },
    amount:{
        type: Number
    },   
    paymentId:{
        type:String
    },
  },  
  { timestamps: true }
  );

  const subscribeuserModel = mongoose.model("subcribe", subscribeUser);
  module.exports = subscribeuserModel;