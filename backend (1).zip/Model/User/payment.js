const mongoose = require("mongoose");
const { ObjectId } = mongoose.Schema.Types;

const UserpaymentSchema = new mongoose.Schema(
    {
        userid:{
            type: ObjectId,
            ref:"users"
        },
        paymentamount:{
            type:String
        },
        paymentid:{
            type:String
        },
        paymentdateandtime:{
            type:String
        },
        status:{
            type:String
        }
},
{timestamps:true});

const Paymentuser = mongoose.model("payment", UserpaymentSchema);

module.exports = Paymentuser;