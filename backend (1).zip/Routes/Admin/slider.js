const express = require("express");
const router = express.Router();
const multer = require("multer");
const adminsliderontroller = require("../../Controller/Admin/slider");

var storage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, "Public/slider");
    },
    filename: function (req, file, cb) {
      cb(null, Date.now() + "_" + file.originalname);
    },
  });

const upload = multer({ storage: storage });

router.post("/addslider", upload.single("slider"), adminsliderontroller.postSlider);
router.get("/getslider", adminsliderontroller.getSlider);
router.post("/deleteslider/:sliderid", adminsliderontroller.deleteSlider);

module.exports = router;