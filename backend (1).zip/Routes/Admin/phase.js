const express = require('express');
const router = express.Router();
const multer = require('multer');
const adminphasecontroller = require('../../Controller/Admin/phase');

var storage = multer.diskStorage({
    destination: function(req, file, cb){
        cb(null, 'Public/phase');
    },
    filename: function(req, file, cb){
        cb(null, Date.now() + "_" + file.originalname);
    },
});

const upload = multer({storage: storage});

router.post("/addphase", upload.single('phaseimage'), adminphasecontroller.postphase);
router.get("/getphase", adminphasecontroller.getphase);
router.post("/deletephase/:phaseid", adminphasecontroller.deletephase);

module.exports = router;