const express = require("express");
const router = express.Router();
const adminauthontroller = require("../../Controller/Admin/admin");

router.post("/signup", adminauthontroller.AdminSignup);
router.post("/signin", adminauthontroller.Postadminlogin);
router.get("/signout/:adminid", adminauthontroller.adminSignout);

module.exports = router;