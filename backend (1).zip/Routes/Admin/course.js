const express = require('express');
const router = express.Router();
const multer = require('multer');
const admincoursecontroller = require('../../Controller/Admin/course');

var storage = multer.diskStorage({
    destination: function(req, file, cb){
        cb(null, 'Public/course');
    },
    filename: function(req, file, cb){
        cb(null, Date.now() + "_" + file.originalname);
    },
});

const upload = multer({storage: storage});

router.post("/addcourse", upload.single("courseimage"), admincoursecontroller.postcourse);
router.get("/getcourse", admincoursecontroller.getcourse);
router.get("/getphasecourse/:phaseid", admincoursecontroller.getsinglecourse);
router.post("/deletecourse/:courseid", admincoursecontroller.deletecourse);

module.exports = router;