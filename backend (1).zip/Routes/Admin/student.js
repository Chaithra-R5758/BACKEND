const express = require('express');
const router = express.Router();
const multer = require('multer');
const adminstudentcontroller = require('../../Controller/Admin/student');

var storage = multer.diskStorage({
    destination: function(req, file, cb){
        cb(null, 'Public/student');
    },
    filename: function(req, file, cb){
        cb(null, Date.now() + "_" + file.originalname);
    },
});

const upload = multer({storage: storage});

router.post("/addstudent", upload.single('studentimage'), adminstudentcontroller.poststudent);
router.get("/getstudent", adminstudentcontroller.getstudent);
router.post("/deletestudent/:studentid", adminstudentcontroller.deletestudent);

module.exports = router;