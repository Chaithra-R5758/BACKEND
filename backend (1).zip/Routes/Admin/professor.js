const express = require('express');
const router = express.Router();
const multer = require('multer');
const adminprofessorcontroller = require('../../Controller/Admin/professor');

var storage = multer.diskStorage({
    destination: function(req, file, cb){
        cb(null, 'Public/professor');
    },
    filename: function(req, file, cb){
        cb(null, Date.now() + "_" + file.originalname);
    },
});

const upload = multer({storage: storage});

router.post("/addprofessor", upload.single('professorimage'), adminprofessorcontroller.postprofessor);
router.get("/getprofessor", adminprofessorcontroller.getprofessor);
router.post("/deleteprofessor/:professorid", adminprofessorcontroller.deleteprofessor);

module.exports = router;