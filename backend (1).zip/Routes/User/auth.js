const express = require("express");
const router = express.Router();
const authController = require("../../Controller/User/auth");
const multer = require("multer");

var storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "Public/userprofile");
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + "_" + file.originalname);
  },
});

const upload = multer({ storage: storage });

router.post("/signup", upload.single("profile"), authController.postSignup);
router.post("/signin", authController.postSignin);
router.post("/loginwithmobile", authController.loginwithmobile);
router.get("/signout/:userid", authController.getsignout);

module.exports = router;

