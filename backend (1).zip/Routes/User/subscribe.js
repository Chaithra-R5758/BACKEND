const express = require("express");
const router = express.Router();
const subcribecontroller = require("../../Controller/User/subscribe");


router.post("/postsubscribe", subcribecontroller.posttransaction);
router.get("/gettransactionorderdetails", subcribecontroller.gettransactiondetails);

module.exports=router ;