const express = require("express");
const router = express.Router();
const AuthpaymentController = require("../../Controller/User/payment");


router.get("/userpayment/:userid", AuthpaymentController.getuserpayment);
router.get("/getpaiduser", AuthpaymentController.getpayment);
router.get("/getuser", AuthpaymentController.getuser);
router.post("/postpayment", AuthpaymentController.postpayment);

module.exports=router ;