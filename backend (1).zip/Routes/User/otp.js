const express = require("express");
const router = express.Router();
const authotpController = require("../../Controller/User/otp");


router.post("/sendotp",authotpController.sendotp);
router.post("/verifyotp",authotpController.verifyotp);

module.exports=router ;