const ProfessorModel = require('../../Model/Admin/professor');

class Professor{

    async postprofessor(req,res) {
        let{professorname, position, instagram, facebook, whatsapp} = req.body;
        let file = req.file?.filename;
        try {
            let newprofessor = new ProfessorModel({
                professorname, position, professorimage:file, instagram, facebook, whatsapp
            }) 
            let save = newprofessor.save();
            if(save){
                return res.status(200).json({success:'Professor added'});
            }else{
                return res.status(500).json({error:'something went wrong'});
            }
        } catch (error) {
            console.log(error);
        }
    }

    async getprofessor(req,res){
        const professor = await ProfessorModel.find({});
        if(professor){
            return res.status(200).json({success:professor});
        }else{
            return res.status(404).json({error:'cannot able to do'});
        }
    }

    async deleteprofessor(req,res){
       let professor = req.params.professorid;
       const data = await ProfessorModel.deleteOne({_id:professor});
       if(data){
           console.log(data)
           return res.json({success:'deleted successfully' })
       }else{
        return res.json({error:'cannot able to do' })
       }
       
    }

}

const adminprofessorcontroller = new Professor();
module.exports = adminprofessorcontroller;
