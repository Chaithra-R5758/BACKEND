const sliderModel = require("../../Model/Admin/slider");


class Slider{
    async postSlider(req,res) {
        let{ content } = req.body;
        let file = req.file?.filename;
        try {
            let newslider = new sliderModel({
                content, 
                slider:file,
            })
            let save = newslider.save();
            if(save){
                return res.status(200).json({success:"Slider Added"});
            }else{
                return res.status(500).json({Error:"Something wrong"});
            }
        } catch (error) {
            console.log(error);
        }
    }

    async getSlider(req,res){
        const slider = await sliderModel.find({});
        if(slider){
            return res.status(200).json({ success: slider });
        }else{
            return res.status(403).json({ error: "not able to find" });
        }
    }

    async deleteSlider(req,res){
        let slider = req.params.sliderid;
        const data = await sliderModel.deleteOne({ _id: slider });
        if(data){
            return res.json({ success: "Deleted Successfully" });
        }else{
            return res.json({error: "not able to complete" });
        }
        
    }
}

const adminsliderontroller = new Slider();
module.exports = adminsliderontroller;