const adminModel = require("../../Model/Admin/auth");

class Admin{
     
    async AdminSignup(req,res){
        let{name, email, password} = req.body
        try {
            let Newuser = new adminModel({
                name, email, password
            }); 
            Newuser.save().then((data)=>{
                console.log(data)
                return res.status(200).json({success:"success"})
            })
        } catch (error) {
            console.log(error);
        }
    }

    async Postadminlogin(req, res){
        let { email, password } = req.body;
        try {
            if(!email || !password){
                return res.status(500).json({error: "Please fill all fields"})
            }else{
                const data = await adminModel.findOne({email, password})
                if(!data){
                    return res.status(500).json({error:"invalid email or password"})
                }else {
                    return res.status(200).json({success:"login success", user: data})
                }
            }
        } catch (error) {
            console.log(error);
        }       
    }

    async adminSignout(req, res){
        let signout = req.params.adminid;
        try {
             await adminModel.findOneAndUpdate({_id: signout},{status: "Offline"})
             .then((data)=> {return res.json({Success:"Signout Successfully"})})
            //  .catch((err)=> {return res.status({error:"Something went wrong"})})
        } catch (error) {
            console.log(error)
        }
    }
}



const adminauthontroller = new Admin();
module.exports = adminauthontroller;