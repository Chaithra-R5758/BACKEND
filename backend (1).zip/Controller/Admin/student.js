const studentModel = require('../../Model/Admin/student');

class Student{
    async poststudent(req,res) {
        let{studentname, feedback} = req.body;
        let file = req.file?.filename;
        try {
            let newstudent = new studentModel({
                studentname, feedback, studentimage:file
            }) 
            let save = newstudent.save();
            if(save){
                return res.status(200).json({success:'Student added'});
            }else{
                return res.status(500).json({error:'something went wrong'});
            }
        } catch (error) {
            console.log(error);
        }
    }

    async getstudent(req,res){
        const student = await studentModel.find({});
        if(student){
            return res.status(200).json({success:student});
        }else{
            return res.status(404).json({error:'cannot able to do'});
        }
    }

    async deletestudent(req,res){
       let student = req.params.studentid;
       const data = await studentModel.deleteOne({_id:student});
       if(data){
           console.log(data)
           return res.json({success:'deleted successfully' })
       }else{
        return res.json({error:'cannot able to do' })
       }
       
    }

}

const adminstudentcontroller = new Student();
module.exports = adminstudentcontroller;