const courseModel = require("../../Model/Admin/course");

class Course{
    async postcourse(req,res){
        let{coursename, coursefor, fees, courseperiod, phaseid } = req.body
        let file = req.file?.filename;
        try {
            let newcourse = new courseModel({
                phaseid,
                coursename, 
                coursefor, 
                fees, 
                courseperiod, 
                courseimage : file
            }) 
            let save = newcourse.save();
            if(save){
                return res.status(200).json({success:"course added"})
            }else{
                return res.status(500).json({error:"course not added"})
            }
        } catch (error) {
            console.log(error);
        }
    }
    
    async getcourse(req, res){
        const course = await courseModel.aggregate([
            {
              '$lookup': {
                'from': 'phases', 
                'localField': 'phaseid', 
                'foreignField': '_id', 
                'as': 'phases'
              }
            }
          ]);
        if(course){
            return res.status(200).json({success:course});
        }else{
            return res.status(404).json({error:'cannot able to do'});
        }
    }


    async getsinglecourse(req, res) {
        let id = req.params.phaseid;
        const course = await courseModel.find({phaseid: id }).sort({ coursename: -1 });
        if (course) {
          return res.json({ course: course });
        }
      }

    async deletecourse(req,res){
        let course = req.params.courseid;
        const data = await courseModel.deleteOne({_id:course});
        if(data){
            console.log(data)
            return res.json({success:'deleted successfully' })
        }else{
            return res.json({error:'cannot able to do' })
           }
    }
}

const admincoursecontroller = new Course();
module.exports = admincoursecontroller;