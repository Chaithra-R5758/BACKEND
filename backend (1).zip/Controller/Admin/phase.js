const phaseModel = require('../../Model/Admin/phase');

class Phase{
    async postphase(req,res) {
        let{phasename, phasetitle} = req.body;
        let file = req.file?.filename;
        try {
            let newphase = new phaseModel({
                phasename, phasetitle, phaseimage:file
            }) 
            let save = newphase.save();
            if(save){
                return res.status(200).json({success:'phase added'});
            }else{
                return res.status(500).json({error:'something went wrong'});
            }
        } catch (error) {
            console.log(error);
        }
    }

    async getphase(req,res){
        const phase = await phaseModel.find({});
        if(phase){
            return res.status(200).json({success:phase});
        }else{
            return res.status(404).json({error:'cannot able to do'});
        }
    }

    async deletephase(req,res){
       let phase = req.params.phaseid;
       const data = await phaseModel.deleteOne({_id:phase});
       if(data){
           console.log(data)
           return res.json({success:'deleted successfully' })
       }else{
        return res.json({error:'cannot able to do' })
       }
       
    }

}

const adminphasecontroller = new Phase();
module.exports = adminphasecontroller;