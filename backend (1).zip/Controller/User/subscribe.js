const subscribeUser = require("../../Model/User/Subscribe");

class Subscribe {
  async posttransaction(req, res) {
    let { name, email, mobile, address, institute, amount, studentid } = req.body;
    if (!name || !email || !mobile || !address || !institute || !studentid) {
      return res.status(500).json({ error: "All field must not be empty" });
    } else {
      try {
        let newsub = new subscribeUser({
          name,
          studentid,
          email,
          mobile,
          address,
          institute,
          amount,
        });
        let save = newsub.save();
        if (save) {
          return res.status(200).json({ success: "done" });
        } else {
          return res.status(500).json({ error: "something went wrong" });
        }
      } catch (error) {
        console.log(error);
      }
    }
  }

  async gettransactiondetails(req,res){
    let transaction = await subscribeUser.find({});
        if (transaction) {
          return res.status(200).json({ transaction: transaction });
        } else {
          return res.status(500).json({ error: "something went wrong" });
        }
       
    }

}
const subcribecontroller = new Subscribe();
module.exports = subcribecontroller;
