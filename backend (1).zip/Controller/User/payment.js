const Paymentuser=require("../../Model/User/payment");

class authpayment{
    async postpayment(req,res){
       let {
        userid,
        paymentamount, 
        paymentid,
        paymentdateandtime,
        status,
       }=req.body;
    //    if(req){
    //        return res.json({messaage:"file success"})
    //    }
    //    else{
           try{
             let newpayment = new Paymentuser({
                userid,
                paymentamount, 
                paymentid,
                paymentdateandtime,
                status,
                 })
             let save= newpayment.save();
             if(save){
                 return res.json({success:"Created Successfully"})
             }
           }
           catch(err){
               console.log(err)
           }
    }

    async getpayment(req,res){
        try{
            let payment1=await Paymentuser.find({});
               if(payment1){
                  return res.json({payment1:payment1})
              }
        }
       catch(err){
           console.log(err)
       }
    }
  
    async getuserpayment(req, res){
        const user = req.params.userid
        try {
            let payment1 = await Paymentuser.findOne({userid:user});
            if(payment1){
               return res.json({payment1:payment1})
           }else{
               return res.json({payment1: {}})
           }
        } catch (error) {
            console.log(err)
        }
    }


    async getuser(req, res){
        const user = await Paymentuser.aggregate([
            {
              '$lookup': {
                'from': 'users', 
                'localField': 'userid', 
                'foreignField': '_id', 
                'as': 'users'
              }
            }
          ]);
        if(user){
            return res.status(200).json({success:user});
        }else{
            return res.status(404).json({error:'cannot able to do'});
        }
    }

    async postdeletepayment(req, res) {
        let id = req.params.id;
        const data = await Paymentuser.deleteOne({ _id: id });
        return res.json({ success: "Successfully" });
    }

}
const AuthpaymentController=new authpayment;
module.exports=AuthpaymentController;