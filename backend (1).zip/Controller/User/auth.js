const userModel = require("../../Model/User/user");
const { validateEmail, toTitleCase, phonenumber } = require("../../Config/function");
// const phonenumber = require("../Config/function");
const bcrypt = require("bcryptjs");

class Auth {
    async postSignup(req, res)  {
        let {name, email, mobile, password, cpassword } = req.body;
        let profile = req.file.filename;
        if(!name || !email || !mobile || !password || !cpassword){
            return res.status(500).json({error:"All field must not be empty"});
        }else if(name.length < 3 && name > 25){
            return res.status(500).json({error:"Name must be 3-25 charecter"})
        }else if(password !== cpassword){
            return res.status(500).json({error:"password mismatch"})
        }
        else if(password.length < 8){
            return res.status(500).json({error:"password should be more than 8"})
        }else if(!validateEmail(email)){
            
            return res.status(500).json({ error: "Email is not valid" });
        }else{
            try {
                password = bcrypt.hashSync(password, 10);
                name = toTitleCase(name);
                const Email = await userModel.findOne({ email:email });
                if(Email){
                    return res.status(500).json({error:"Email already exits"})
                }
                const phone = await userModel.findOne({ mobile: mobile });
                if(phone){
                    return res.status.json({error:"mobile number already exits"})
                }
                let Newuser = new userModel({
                    name, email, mobile, password, profile
                });
                Newuser.save().then((data) =>  {
                    console.log(data)
                    return res.status(200).json({Success:"Signup Success, Please login"})
                } );              
            } catch (error) {
                console.log(error)
            }
        }
    }

    async postSignin(req, res){
        let { email, password } = req.body;
        try {
            if(!email || !password){
                return res.status(500).json({error: "Please fill all fields"})
            }else{
                const data = await userModel.findOne({email})
                if(!data){
                    return res.status(500).json({error:"invalid email"})
                }else{
                    const passcheck = bcrypt.compare(password, data.password)
                    if(passcheck){
                        userModel.findOneAndUpdate({email},{status:"Online"})
                        return res.json({Success: "Signin successful", user: data})
                    }else{
                        return res.status(500).json({error:"Invalid Password"})
                    }
                }
            }            
        } catch (error) {
            console.log(error)            
        }
    }

    async loginwithmobile(req, res){
        let { mobile, password } = req.body;
        try {
            if(!mobile || !password){
                return res.status(500).json({error: "Please fill all fields"})
            }else{
                const data = await userModel.findOne({mobile: mobile})
                if(!data){
                    return res.status(500).json({error:"invalid mobile number"})
                }else{
                    const passcheck = bcrypt.compare(password, data.password)
                    if(passcheck){
                        userModel.findOneAndUpdate({mobile},{status:"Online"})
                        return res.json({Success: "Signin successful", user: data})
                    }else{
                        return res.status(500).json({error:"Invalid Password"})
                    }
                }
            }            
        } catch (error) {
            console.log(error)            
        }
    }

    async getsignout(req, res){
        let signout = req.params.userid;
        try {
             await userModel.findOneAndUpdate({_id: signout},{status: "Offline"})
             .then((data)=> {return res.json({Success:"Signout Successfully"})})
             .catch((err)=> {return res.status({error:"Something went wrong"})})
        } catch (error) {
            console.log(error)
        }
    }

}
const authController = new Auth();
module.exports = authController;